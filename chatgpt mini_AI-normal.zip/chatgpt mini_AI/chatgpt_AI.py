#!/usr/bin/env python3
import os, platform, difflib, math, ast, operator as op, warnings, socket, shutil
from pathlib import Path
from datetime import datetime

warnings.filterwarnings("ignore", category=DeprecationWarning)

AI_NAME = "chatgpt mini ai"
HISTORY = []
SCRIPT_PATH = Path(__file__)
LAST_CODE_TIME = SCRIPT_PATH.stat().st_mtime

# ---------- UI helpers ----------

def is_online():
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=1)
        return True
    except OSError:
        return False

def draw_ui():
    cols, rows = shutil.get_terminal_size()
    status = "ONLINE" if is_online() else "OFFLINE"

    # save cursor
    print("\033[s", end="")

    # top right status
    print(f"\033[1;{cols-len(status)}H{status}", end="")

    # bottom left text
    print(f"\033[{rows};1Hlove god", end="")

    # restore cursor
    print("\033[u", end="", flush=True)

# --- safe math evaluator ---
allowed_operators = {
    ast.Add: op.add,
    ast.Sub: op.sub,
    ast.Mult: op.mul,
    ast.Div: op.truediv,
    ast.Pow: op.pow,
    ast.Mod: op.mod,
    ast.USub: op.neg,
}

def eval_math(expr):
    try:
        node = ast.parse(expr, mode='eval').body
        return _eval(node)
    except Exception:
        return None

def _eval(node):
    if isinstance(node, ast.Constant):
        return node.value
    elif isinstance(node, ast.BinOp):
        return allowed_operators[type(node.op)](_eval(node.left), _eval(node.right))
    elif isinstance(node, ast.UnaryOp):
        return allowed_operators[type(node.op)](_eval(node.operand))
    else:
        raise ValueError("Invalid math")

class Brain:
    def __init__(self):
        self.brain_path = None
        self.qa = {}
        self.last_modified = 0
        self.load()

    def find_downloads(self):
        home = Path.home()
        candidates = [home/"Downloads", Path(os.environ.get("USERPROFILE", home))/"Downloads"]
        for c in candidates:
            if c.exists():
                return c
        return home

    def locate_brain(self):
        return self.find_downloads()/"chatgpt mini_AI"/"data"/"school.txt"

    def load(self):
        self.qa.clear()
        self.brain_path = self.locate_brain()
        if not self.brain_path.exists():
            return
        try:
            self.last_modified = self.brain_path.stat().st_mtime
            with open(self.brain_path, "r", encoding="utf-8") as f:
                for line in f:
                    if "=" in line:
                        q, a = line.strip().split("=", 1)
                        self.qa[q.lower()] = a
        except Exception:
            pass

    def auto_refresh(self):
        if self.brain_path.exists():
            new_time = self.brain_path.stat().st_mtime
            if new_time != self.last_modified:
                self.load()
                print(f"\n{AI_NAME}: brain updated")

    def normalize(self, text):
        import re
        text = text.lower()
        text = re.sub(r"[^a-z0-9\s]", "", text)
        return " ".join(text.split())

    def search(self, question):
        if not self.qa:
            return "Brain not found. Put school.txt in Downloads/chatgpt mini_AI/data/"
        qn = self.normalize(question)
        best = None
        best_score = 0.0
        for k in self.qa.keys():
            score = difflib.SequenceMatcher(None, qn, self.normalize(k)).ratio()
            if score > best_score:
                best_score = score
                best = k
        if best and best_score > 0.45:
            return self.qa[best]
        return "I don't know that yet."

brain = Brain()

# --- Commands ---

def restart():
    global brain
    HISTORY.clear()
    os.system('cls' if os.name == 'nt' else 'clear')
    brain = Brain()
    print(AI_NAME)
    draw_ui()


def clear():
    HISTORY.clear()
    os.system('cls' if os.name == 'nt' else 'clear')
    print(AI_NAME)
    draw_ui()

# --- Main Loop ---

def main():
    print(AI_NAME)
    draw_ui()
    while True:
        try:
            brain.auto_refresh()
            draw_ui()

            cmd = input("you: ").strip()
            if not cmd:
                continue

            HISTORY.append(cmd)

            math_result = eval_math(cmd)
            if math_result is not None:
                print(AI_NAME + ":", math_result)
                continue

            if cmd == "exit":
                break
            elif cmd == "restart":
                restart()
                continue
            elif cmd == "clear":
                clear()
                continue
            elif cmd == "system":
                print(AI_NAME + ":", platform.platform())
                continue
            elif cmd == "time":
                print(AI_NAME + ":", datetime.now().strftime("%H:%M:%S"))
                continue
            elif cmd == "date":
                print(AI_NAME + ":", datetime.now().strftime("%Y-%m-%d"))
                continue

            answer = brain.search(cmd)
            print(AI_NAME + ":", answer)

        except KeyboardInterrupt:
            print("\nExiting.")
            break
        except Exception as e:
            print("Error:", e)


if __name__ == "__main__":
    main()